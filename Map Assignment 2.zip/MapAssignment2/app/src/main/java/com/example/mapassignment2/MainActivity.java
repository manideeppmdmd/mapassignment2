package com.example.mapassignment2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentManager;

import android.Manifest;
import android.app.Dialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_FINE_LOCATION = 2;
    RadioButton location, all_loactions, color;
    boolean l = false, s = false, c = false;
    Dialog colors;
    LinearLayout head;
    EditText colortxt;
    Button done;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkPermissions();
        location = (RadioButton) findViewById(R.id.getCurrentLocation);
        all_loactions= (RadioButton) findViewById(R.id.showAllLocations);
        color = (RadioButton) findViewById(R.id.changeBackgroundColour);
        final RadioGroup radio = (RadioGroup) findViewById(R.id.radio);

        final FragmentManager manager = getSupportFragmentManager();
        head = (LinearLayout) findViewById(R.id.main);
        colors = new Dialog(this);
        colors.setContentView(R.layout.colordialog);
        colortxt = (EditText) colors.findViewById(R.id.color);
        done = (Button) colors.findViewById(R.id.ok);

        location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!l) {
                    location.setChecked(true);
                    location_fragment frag = new location_fragment();
                    manager.beginTransaction().replace(R.id.frame, frag).commit();
                    l = true;
                } else {
                    manager.beginTransaction().remove(getSupportFragmentManager().findFragmentById(R.id.frame)).commit();
                    location.setChecked(false);
                    l = false;
                }
            }
        });


        color.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                colors.show();
                color.setChecked(true);
            }
        });

        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String c = colortxt.getText().toString();

                switch (c) {
                    case "yellow": {
                        head.setBackgroundColor(Color.parseColor("#ffff00"));
                        break;
                    }

                    case "red": {
                        head.setBackgroundColor(Color.parseColor("#ef7878"));
                        break;
                    }

                    case "blue": {
                        head.setBackgroundColor(Color.parseColor("#0000ff"));
                        break;
                    }

                    case "green": {
                        head.setBackgroundColor(Color.parseColor("#00ff00"));
                        break;
                    }

                    case "white": {
                        head.setBackgroundColor(Color.parseColor("#ffffff"));
                        break;
                    }


                }

                colors.dismiss();
            }
        });

        all_loactions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!s){
                    all_loactions.setChecked(true);
                    ListviewFragment frag = new ListviewFragment();
                    manager.beginTransaction().replace(R.id.frame, frag).commit();
                    s = true;
                } else {
                    manager.beginTransaction().remove(getSupportFragmentManager().findFragmentById(R.id.frame)).commit();
                    all_loactions.setChecked(false);
                    s = false;
                }
            }
        });


    }

        public void onRequestPermissionsResult ( int requestCode, @NonNull String[] permissions,
        @NonNull int[] grantResults){

            if (requestCode == PERMISSION_FINE_LOCATION) {
                // Request for camera permission.
                if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission has been granted. Start location preview Activity.
                    Toast.makeText(MainActivity.this, "Permission Enabled!", Toast.LENGTH_SHORT).show();

                } else {
                    // Permission request was denied.

                    Toast.makeText(MainActivity.this, "Set Location Permission!", Toast.LENGTH_SHORT).show();
                }
            }


        }

    void checkPermissions() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
        } else {
            requestFineLocationPermission();
        }

    }
        private void requestFineLocationPermission () {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        PERMISSION_FINE_LOCATION);

            } else {
                // Request the permission. The result will be received in onRequestPermissionResult().
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_FINE_LOCATION);
            }
        }

    }