package com.example.mapassignment2;


import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Random;


public class location_fragment extends Fragment {

    private FusedLocationProviderClient fusedLocationClient;

    EditText lat,lon,locationname;
    Button getloc;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_location_fragment, container, false);


        fusedLocationClient = LocationServices.getFusedLocationProviderClient(getActivity());

        lat = (EditText) view.findViewById(R.id.editLocationLatitude);
        lon = (EditText) view.findViewById(R.id.editLocationLongitutude);
        locationname = (EditText) view.findViewById(R.id.editLocationName);
        getloc = (Button) view.findViewById(R.id.button);


        getloc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ActivityCompat.checkSelfPermission(getActivity(),Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(),Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                }
                fusedLocationClient.getLastLocation().addOnSuccessListener(getActivity(), new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {

                        if(location!=null)
                        {
                            double lt = location.getLatitude();
                            double ln = location.getLongitude();

                            lat.setText(lt+"");
                            lon.setText(ln+"");
                            String cityName= "";
                            Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());
                            List<Address> addresses = null;
                            try {
                                addresses = geocoder.getFromLocation(lt, ln, 1);
                                cityName = addresses.get(0).getAddressLine(0);
                                locationname.setText(cityName);
                            } catch (IOException e) {
                                e.printStackTrace();
                                Toast.makeText(getActivity(),"Geocoder cannot track city name",Toast.LENGTH_SHORT).show();
                            }

                            long time = System.currentTimeMillis();
                            String timeStamp = new SimpleDateFormat(" HH:mm:ss dd-MM-yyyy").format(Calendar.getInstance().getTime());

                            FirebaseDatabase.getInstance().getReference("Locations")
                                    .child(time+" Entry")
                                    .setValue("Latitude: "+lt+" Longitude: "+ln+" Address: "+cityName+" Time: "+timeStamp);

                        }
                        else {
                            Toast.makeText(getActivity(),"Please turn on gps!",Toast.LENGTH_SHORT).show();
                        }

                    }
                });
            }
        });




        return view;
    }

}
